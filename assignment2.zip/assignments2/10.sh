# Author : Mihir Mithani

#!/bin/bash

array=(1 2 3 4 5)

echo ${array[*]}
